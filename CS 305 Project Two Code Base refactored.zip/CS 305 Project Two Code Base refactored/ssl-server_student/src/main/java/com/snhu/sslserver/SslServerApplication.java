package com.snhu.sslserver;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

	
}
//FIXME: Add route to enable check sum return of static data example:  String data = "Hello World Check Sum!";
@RestController
class ServerController {
	// Define a character array to store the hex digits (0-9, A-F)
	private static final char[] HEX_ARRAY = "0123456789ABCDEF".toCharArray();

	// Method to generate a SHA-256 hash of the input string
	private String getHash(String input) {
		try {
			// Create a MessageDigest instance for SHA-256 hashing
			MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
			// Get the digest (hash) of the input string
			byte[] messageDigestMD5 = messageDigest.digest();
			// Convert the byte array to a hex string using the bytesToHex method
			return bytesToHex(messageDigestMD5);
		} catch (NoSuchAlgorithmException e) {
			// Handle the exception if the SHA-256 algorithm is not found
			e.printStackTrace();
		}
		// Return the original input string if an error occurs
		return input;
	}
	
	public static String bytesToHex(byte[] bytes) {
		// Create a character array to store the hex representation, with each byte represented by two characters
		char[] hexChars = new char[bytes.length * 2];

		// Iterate over each byte in the input array
		for (int j = 0; j < bytes.length; j++) {

			// Get the unsigned value of the byte
			int v = bytes[j] & 0xFF;
			// Get the high and low nibbles of the byte
			hexChars[j * 2] = HEX_ARRAY[v >>> 4]; // high nibble
			hexChars[j * 2 + 1] = HEX_ARRAY[v & 0x0F]; // low nibble
		}
		// Return the hex string representation of the bytes
		return new String(hexChars);
	}

	@RequestMapping("/hash")
	public String myHash() {
		// Define the input data to be hashed
		String data = "Mitchell Fontaine: Hello World Check Sum!";
		// Call the getHash method to generate the SHA-256 hash of the input data
		String hash = getHash(data);
		// Return an HTML paragraph with the original data and the generated hash
		return "<p>data: " + data + "</p><p> Name of Cipher Used: SHA-256 Value: " + hash;
	}
}